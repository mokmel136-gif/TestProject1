import 'package:get/get.dart';
import '../services_ِapi/api_service.dart';
import '../models/product_item.dart';
import '../models/category_item.dart';

class ProductController extends GetxController {
  final ApiService _apiService = ApiService();
  
  var isLoading = false.obs;
  var products = <ProductItem>[].obs;
  var categories = <CategoryItem>[].obs;
  var filteredProducts = <ProductItem>[].obs;

  @override
  void onInit() {
    super.onInit();
    loadCategories();
    loadProducts();
  }

  Future<void> loadCategories() async {
    try {
      isLoading.value = true;
      categories.value = await _apiService.getCategories();
    } catch (e) {
      Get.snackbar('خطأ', 'حدث خطأ أثناء تحميل الفئات');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> loadProducts() async {
    try {
      isLoading.value = true;
      products.value = await _apiService.getProducts();
      filteredProducts.value = products;
    } catch (e) {
      Get.snackbar('خطأ', 'حدث خطأ أثناء تحميل المنتجات');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> loadProductsByCategory(int categoryId) async {
    try {
      isLoading.value = true;
      filteredProducts.value = await _apiService.getProductsByCategory(categoryId);
    } catch (e) {
      Get.snackbar('خطأ', 'حدث خطأ أثناء تحميل منتجات الفئة');
    } finally {
      isLoading.value = false;
    }
  }

  void searchProducts(String query) {
    if (query.isEmpty) {
      filteredProducts.value = products;
    } else {
      filteredProducts.value = products
          .where((product) => 
              product.name.toLowerCase().contains(query.toLowerCase()) ||
              (product.description?.toLowerCase().contains(query.toLowerCase()) ?? false))
          .toList();
    }
  }
}

