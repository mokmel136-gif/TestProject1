// lib/controllers/shop_controller.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../models/cart_item.dart';
import '../models/product_item.dart';
import '../models/productCategory_item.dart';

class ShopController extends GetxController {
  var categories = <ProdcutCategoryItem>[].obs;
  var products = <ProductItem>[].obs;
  var cartItems = <CartItem>[].obs;
  var isLoading = false.obs;
  final box = GetStorage();
  static const cartKey = 'cartItems';

  // قاعدة URL للـ API - غيرها حسب عنوان الخادم الخاص بك
  static const String baseUrl = 'http://192.168.18.8:8000/api';

  double get cartTotal =>
      cartItems.fold(0, (sum, item) => sum + (item.price * item.quantity));
  int get cartItemsCount =>
      cartItems.fold(0, (sum, item) => sum + item.quantity);

  @override
  void onInit() {
    super.onInit();
    loadCategoriesFromApi();
    loadCart();
  }

  // جلب التصنيفات من API
  Future<void> loadCategoriesFromApi() async {
    try {
      isLoading.value = true;
      final response = await http.get(Uri.parse('$baseUrl/categories'));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        categories.value = data
            .map((category) => ProdcutCategoryItem.fromJson(category))
            .toList();
      } else {
        // إذا فشل الاتصال، استخدم البيانات المحلية كنسخة احتياطية
        loadLocalCategories();
      }
    } catch (e) {
      print('Error loading categories: $e');
      loadLocalCategories();
    } finally {
      isLoading.value = false;
    }
  }

  // نسخة احتياطية من التصنيفات المحلية
  void loadLocalCategories() {
    categories.value = [
      ProdcutCategoryItem(
        name: "الأجهزة",
        icon: Icons.devices,
        subcategories: ["ثلاجات", "غسالات", "مكيفات", "أفران"],
        id: null,
      ),
      ProdcutCategoryItem(
        name: "السباكة",
        icon: Icons.plumbing,
        subcategories: ["أنابيب", "حنفيات", "مضخات"],
        id: 1,
      ),
      ProdcutCategoryItem(
        name: "الكهرباء",
        icon: Icons.electrical_services,
        subcategories: ["أسلاك", "مفاتيح", "لمبات"],
        id: null,
      ),
      ProdcutCategoryItem(
        name: "الدهانات",
        icon: Icons.format_paint,
        subcategories: ["دهانات جدران", "مواد طلاء", "معجون"],
        id: null,
      ),
    ];
  }

  // جلب المنتجات من API حسب التصنيف
  Future<void> loadProducts(String subcategory) async {
    try {
      isLoading.value = true;
      products.clear();

      final response = await http.get(
        Uri.parse('$baseUrl/products?category=$subcategory'),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        products.value = data
            .map((product) => ProductItem.fromJson(product))
            .toList();
      } else {
        // إذا فشل الاتصال، استخدم البيانات المحلية كنسخة احتياطية
        loadLocalProducts(subcategory);
      }
    } catch (e) {
      print('Error loading products: $e');
      loadLocalProducts(subcategory);
    } finally {
      isLoading.value = false;
    }
  }

  // نسخة احتياطية من المنتجات المحلية
  void loadLocalProducts(String subcategory) {
    products.clear();

    if (subcategory == "ثلاجات") {
      products.value = [
        ProductItem(
          id: 1,
          name: "ثلاجة سامسونج 20 قدم",
          description: "ثلاجة حديثة بمواصفات رائعة",
          price: 2500.0,
          image:
              "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=400",
          categoryId: 1,
          stockQuantity: 10,
          isActive: true,
          createdAt: "2023-01-01",
          updatedAt: "2023-01-01",
        ),
        ProductItem(
          id: 2,
          name: "ثلاجة LG 18 قدم",
          description: "ثلاجة عالية الجودة",
          price: 2200.0,
          image:
              "https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=400",
          categoryId: 1,
          stockQuantity: 8,
          isActive: true,
          createdAt: "2023-01-01",
          updatedAt: "2023-01-01",
        ),
      ];
    } else if (subcategory == "غسالات") {
      products.value = [
        ProductItem(
          id: 3,
          name: "غسالة سامسونج 10 كجم",
          description: "غسالة أوتوماتيكية",
          price: 1800.0,
          image:
              "https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=400",
          categoryId: 1,
          stockQuantity: 5,
          isActive: true,
          createdAt: "2023-01-01",
          updatedAt: "2023-01-01",
        ),
      ];
    } else {
      products.value = [
        ProductItem(
          id: 999,
          name: "منتج $subcategory",
          description: "وصف المنتج",
          price: 100.0,
          image:
              "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
          categoryId: 1,
          stockQuantity: 1,
          isActive: true,
          createdAt: "2023-01-01",
          updatedAt: "2023-01-01",
        ),
      ];
    }
  }

  // إضافة منتج إلى السلة مع إرسال إلى API إذا لزم الأمر
  void addToCart(ProductItem product) async {
    // استخدم product.id كـ productId. إذا كان null، استخدم 0 أو تعامل معه كـ غير مسجل
    final int productId = product.id ?? 0;

    final existingItemIndex = cartItems.indexWhere(
      (item) => item.productId == productId,
    );

    if (existingItemIndex >= 0) {
      // زوّد الكمية مع المحافظة على كل الحقول الأخرى
      final existing = cartItems[existingItemIndex];
      cartItems[existingItemIndex] = existing.copyWith(
        quantity: existing.quantity + 1,
      );
    } else {
      // اضف عنصر جديد، احرص أن تمرر productId صحيح و اسم/صورة/سعر من الـ product
      final newItem = CartItem(
        id: null,
        userId: null,
        productId: productId,
        name: product.name,
        image: product.image,
        price: product.price,
        quantity: 1,
        createdAt: null,
        updatedAt: null,
      );
      cartItems.add(newItem);
    }

    saveCart();

    // مزامنة مع API إذا كان المستخدم مسجل ولدى المنتج id صالح
    try {
      final token = box.read('user_token');
      if (token != null && productId != 0) {
        await http.post(
          Uri.parse('$baseUrl/cart'),
          headers: {
            'Authorization': 'Bearer $token',
            'Content-Type': 'application/json',
          },
          body: json.encode({'product_id': productId, 'quantity': 1}),
        );
      }
    } catch (e) {
      print('Error syncing cart with API: $e');
    }

    Get.snackbar('تمت الإضافة', 'تم إضافة ${product.name} إلى السلة');
  }

  void removeFromCart(CartItem item) {
    cartItems.removeWhere((i) => i.productId == item.productId);
    saveCart();
    syncCartWithApi();
  }

  void increaseQuantity(CartItem item) {
    final index = cartItems.indexWhere(
      (cartItem) => cartItem.productId == item.productId,
    );
    if (index >= 0) {
      cartItems[index] = cartItems[index].copyWith(
        quantity: cartItems[index].quantity + 1,
      );
      saveCart();
      syncCartWithApi();
    }
  }

  void decreaseQuantity(CartItem item) {
    final index = cartItems.indexWhere(
      (cartItem) => cartItem.productId == item.productId,
    );
    if (index >= 0) {
      final current = cartItems[index];
      if (current.quantity > 1) {
        cartItems[index] = current.copyWith(quantity: current.quantity - 1);
      } else {
        cartItems.removeAt(index);
      }
      saveCart();
      syncCartWithApi();
    }
  }

  void clearCart() {
    cartItems.clear();
    saveCart();
    syncCartWithApi();
  }

  Future<void> syncCartWithApi() async {
    try {
      final token = box.read('user_token');
      if (token != null) {
        await http.post(
          Uri.parse('$baseUrl/cart/sync'),
          headers: {
            'Authorization': 'Bearer $token',
            'Content-Type': 'application/json',
          },
          body: json.encode(cartItems.map((item) => item.toJson()).toList()),
        );
      }
    } catch (e) {
      print('Error syncing cart: $e');
    }
  }

  void saveCart() {
    final List<Map<String, dynamic>> cartData = cartItems
        .map((item) => item.toJson())
        .toList();
    box.write(cartKey, cartData);
  }

  void loadCart() {
    final data = box.read(cartKey);
    if (data != null) {
      final List<CartItem> loaded = List<Map<String, dynamic>>.from(
        data,
      ).map((e) => CartItem.fromJson(Map<String, dynamic>.from(e))).toList();
      cartItems.assignAll(loaded);
    }
  }
}
