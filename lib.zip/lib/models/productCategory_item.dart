import 'package:flutter/material.dart';

class ProdcutCategoryItem {
  final int? id; // 👈 id اختياري (nullable)
  final String name;
  final IconData icon;
  final List<String> subcategories;

  ProdcutCategoryItem({
    required this.id,
    required this.name,
    required this.icon,
    required this.subcategories,
  });

  factory ProdcutCategoryItem.fromJson(Map<String, dynamic> json) {
    return ProdcutCategoryItem(
      id: json['id'],
      name: json['name'] ?? '',
      subcategories: List<String>.from(json['subcategories'] ?? []),
      icon: Icons.category, //  قيمة افتراضية
    );
  }

  // تحويل إلى JSON
  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "name": name,
      "subcategories": subcategories,
      "icon": icon.codePoint, // تخزين codePoint فقط
    };
  }
}
