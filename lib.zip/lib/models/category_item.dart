class CategoryItem {
  final int id;
  final String name;
  final String? description;
  final String? image;
  final bool isActive;
  final String createdAt;
  final String updatedAt;

  CategoryItem({
    required this.id,
    required this.name,
    this.description,
    this.image,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
  });

  factory CategoryItem.fromJson(Map<String, dynamic> json) {
    return CategoryItem(
      id: json["id"],
      name: json["name"] ?? "",
      description: json["description"],
      image: json["image"],
      isActive: json["is_active"] ?? true,
      createdAt: json["created_at"] ?? "",
      updatedAt: json["updated_at"] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "name": name,
      "description": description,
      "image": image,
      "is_active": isActive,
      "created_at": createdAt,
      "updated_at": updatedAt,
    };
  }
}

