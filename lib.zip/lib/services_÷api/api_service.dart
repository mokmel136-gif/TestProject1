import 'dart:convert';
// import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;

import 'package:my_app1/models/category_item.dart';
import 'package:my_app1/models/product_item.dart';
import 'package:my_app1/models/provider_item.dart';
import 'package:my_app1/models/cart_item.dart';

import '../models/services_Item.dart';

class ApiService {
  static const String baseUrl = 'http://192.168.5.8:8000/api';
  final GetStorage _storage = GetStorage();

  //  جلب التوكن
  Future<String?> getToken() async {
    return _storage.read("auth_token");
  }

  //  حفظ التوكن
  Future<void> saveToken(String token) async {
    await _storage.write("auth_token", token);
  }

  //  حذف التوكن
  Future<void> removeToken() async {
    await _storage.remove("auth_token");
  }

  //  الهيدر مع أو بدون توكن
  Future<Map<String, String>> getHeaders({bool includeAuth = false}) async {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (includeAuth) {
      final token = await getToken();
      if (token != null) {
        headers['Authorization'] = 'Bearer $token';
      }
    }

    return headers;
  }

  //  التسجيل
  Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/register'),
      headers: await getHeaders(),
      body: jsonEncode({'name': name, 'email': email, 'password': password}),
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 201 && data['success']) {
      await saveToken(data['data']['token']);
    }

    return data;
  }

  //  تسجيل الدخول
  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: await getHeaders(),
      body: jsonEncode({'email': email, 'password': password}),
    );

    final data = jsonDecode(response.body);

    if (response.statusCode == 200 && data['success']) {
      await saveToken(data['data']['token']);
    }

    return data;
  }

  //  تسجيل الخروج
  Future<Map<String, dynamic>> logout() async {
    final response = await http.post(
      Uri.parse('$baseUrl/logout'),
      headers: await getHeaders(includeAuth: true),
    );

    if (response.statusCode == 200) {
      await removeToken();
    }

    return jsonDecode(response.body);
  }

  //  جلب بيانات المستخدم
  Future<Map<String, dynamic>> getUser() async {
    final response = await http.get(
      Uri.parse('$baseUrl/user'),
      headers: await getHeaders(includeAuth: true),
    );

    return jsonDecode(response.body);
  }

  Future<List<ServiceItem>> getServices() async {
    final response = await http.get(Uri.parse('$baseUrl/services'));
    print("Raw response: ${response.body}");

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);

      if (data['success']) {
        return (data['data'] as List)
            .map((s) => ServiceItem.fromJson(s))
            .toList();
      } else {
        return [];
      }
    } else {
      throw Exception("فشل في جلب الخدمات");
    }
  }



  

  //  جلب التصنيفات
  Future<List<CategoryItem>> getCategories() async {
    final response = await http.get(
      Uri.parse('$baseUrl/categories'),
      headers: await getHeaders(),
    );

    final data = jsonDecode(response.body);

    if (data['success']) {
      return (data['data'] as List)
          .map((item) => CategoryItem.fromJson(item))
          .toList();
    }

    return [];
  }

  //  جلب المنتجات
  Future<List<ProductItem>> getProducts() async {
    final response = await http.get(
      Uri.parse('$baseUrl/products'),
      headers: await getHeaders(),
    );

    final data = jsonDecode(response.body);

    if (data['success']) {
      return (data['data'] as List)
          .map((item) => ProductItem.fromJson(item))
          .toList();
    }

    return [];
  }

  //  جلب المنتجات حسب التصنيف
  Future<List<ProductItem>> getProductsByCategory(int categoryId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/products/category/$categoryId'),
      headers: await getHeaders(),
    );

    final data = jsonDecode(response.body);

    if (data['success']) {
      return (data['data'] as List)
          .map((item) => ProductItem.fromJson(item))
          .toList();
    }

    return [];
  }

  //  جلب مقدمي الخدمات
  Future<List<ProviderItem>> getProviders() async {
    final response = await http.get(
      Uri.parse('$baseUrl/providers'),
      headers: await getHeaders(),
    );

    final data = jsonDecode(response.body);

    if (data['success']) {
      return (data['data'] as List)
          .map((item) => ProviderItem.fromJson(item))
          .toList();
    }

    return [];
  }

  //  إضافة إلى السلة
  Future<Map<String, dynamic>> addToCart({
    required int productId,
    required int quantity,
    required double price,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/cart'),
      headers: await getHeaders(includeAuth: true),
      body: jsonEncode({
        'product_id': productId,
        'quantity': quantity,
        'price': price,
      }),
    );

    return jsonDecode(response.body);
  }

  //  جلب السلة
  Future<List<CartItem>> getCart() async {
    final response = await http.get(
      Uri.parse('$baseUrl/cart'),
      headers: await getHeaders(includeAuth: true),
    );

    final data = jsonDecode(response.body);

    if (data['success']) {
      return (data['data'] as List)
          .map((item) => CartItem.fromJson(item))
          .toList();
    }

    return [];
  }
}
