import 'package:flutter/material.dart';

class ToolePage extends StatelessWidget {
  const ToolePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text("ادوات وقطعههتتتتتت غيار")));
  }
}
