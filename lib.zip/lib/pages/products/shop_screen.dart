// lib/pages/shop_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_app1/pages/products/productSubcategory_screen.dart';

import '../../controller/shop_controller.dart';
import '../../widgets/SearchBarWidget.dart';
import '../../widgets/productCategory_card.dart';

class ShopScreen extends StatelessWidget {
  ShopScreen({super.key});

  final ShopController shopController = Get.put(ShopController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("الأدوات وقطع الغيار")),
      body: Column(
        children: [
          const SearchBarWidget(), // إضافة شريط البحث هنا
          Expanded(
            child: Obx(() {
              return GridView.builder(
                padding: const EdgeInsets.all(10),
                itemCount: shopController.categories.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 7,
                  mainAxisSpacing: 10,
                ),
                itemBuilder: (context, index) {
                  final category = shopController.categories[index];
                  return ProductCategoryCard(
                    title: category.name,
                    icon: category.icon,
                    onTap: () {
                      Get.to(() => SubCategoryScreen(category: category));
                    },
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }
}
