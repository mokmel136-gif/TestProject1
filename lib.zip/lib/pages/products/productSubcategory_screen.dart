// lib/pages/subcategory_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../models/productCategory_item.dart';
import '../../widgets/ProductSubcategory_card.dart';
import '../../widgets/SearchBarWidget.dart';
import '../CartScreen.dart';
import 'products_screen.dart';

class SubCategoryScreen extends StatelessWidget {
  final ProdcutCategoryItem category;

  const SubCategoryScreen({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(category.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Get.to(() => const CartScreen());
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const SearchBarWidget(), // إضافة شريط البحث هنا
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: category.subcategories.length,
              itemBuilder: (context, index) {
                final sub = category.subcategories[index];
                return ProductSubcategoryCard(
                  title: sub,
                  onTap: () {
                    Get.to(() => ProductsScreen(subcategory: sub));
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
